# RB Dispatch · Rutas Barralaga

PWA de solicitud y cotización logística para Rutas Barralaga · Honduras.

**Estado:** prototipo funcional de interfaz / primera iteración. No es todavía un sistema productivo de despacho, asignación de motoristas ni seguimiento en tiempo real.

## Alcance de esta primera versión

- Portal móvil instalable (PWA) en español.
- Modalidades Express, Multidrop, Ruta Dedicada y Encomienda.
- Formularios diferenciados para cada modalidad.
- Tarjetas independientes para remitente y destinatario.
- Mapa Leaflet / OpenStreetMap con pines para recolección y entrega, búsqueda de direcciones y ruta por carretera mediante OSRM.
- Resumen de valor y estimación preliminar según los parámetros cargados.
- Bloqueo de cargas mayores a 500 kg.
- Borradores guardados únicamente en el almacenamiento local del navegador.

## Ejecutar localmente

El service worker requiere servir el proyecto por HTTP(S). Por ejemplo:

```bash
python -m http.server 8080
```

Abrir `http://localhost:8080` en el navegador. El mapa, la búsqueda geográfica y las rutas requieren conexión a internet y dependen de servicios públicos externos.

## Importante: límites actuales

1. **No hay backend conectado.** Guardar un borrador no lo transmite a Rutas Barralaga. Los datos permanecen en el dispositivo y navegador usados.
2. **No hay autenticación, roles, panel de operaciones, asignación de motorista, GPS de repartidor, notificaciones ni prueba de entrega.**
3. **Las tarifas son referencias iniciales de configuración.** Multidrop está marcado para validación manual; la clasificación crítica, ruta dedicada y encomienda también muestran restricciones de validación.
4. OSRM público y Nominatim público son servicios comunitarios; no constituyen una garantía de disponibilidad ni SLA para producción.
5. No colocar datos personales reales de clientes en este prototipo público hasta implementar backend seguro, controles de acceso, retención y aviso de privacidad.

## Próximos hitos técnicos

1. Conectar Supabase/PostgreSQL con Row Level Security, autenticación y almacenamiento seguro.
2. Crear API de pedidos, estados y bitácora inmutable de eventos.
3. Implementar panel de despacho con mapa en vivo, operadores, motoristas y asignación manual/recomendada.
4. Crear PWA de motorista con GPS, cambios de estado y prueba de entrega georreferenciada.
5. Portal público de seguimiento con token temporal, notificaciones y políticas de privacidad.
6. Pruebas automatizadas de tarifas, límites de carga, transiciones de estado, autorización y seguridad.

## Referencia de arquitectura

Se revisó OwnFleet (`Volodymyr4K/ownfleet`) como referencia de arquitectura para separar API, consola de operaciones, app de motorista y seguimiento de cliente. RB Dispatch no reutiliza su código ni incorpora automáticamente sus supuestos de negocio.
