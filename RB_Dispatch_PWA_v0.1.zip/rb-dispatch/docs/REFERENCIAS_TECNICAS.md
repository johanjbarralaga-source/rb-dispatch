# Referencias técnicas revisadas

Se hizo una revisión rápida de repositorios públicos para identificar patrones de arquitectura. No se copió código ni se asumió que las reglas comerciales de esos proyectos aplican a Rutas Barralaga.

## Referencia principal: OwnFleet

https://github.com/Volodymyr4K/ownfleet

Plataforma de última milla para flotas propias, con panel de manager, aplicación de motorista y seguimiento de clientes. Su README documenta mapa Leaflet, despacho manual/recomendado/automático, GPS, ETA, prueba de entrega georreferenciada, API REST/WebSocket y un backend modular con PostgreSQL/PostGIS y Redis.

**Qué conviene estudiar:** separación de aplicaciones por rol, máquina de estados, prueba de entrega, seguridad del seguimiento público, modelo de turnos y asignación.

**Qué no conviene copiar de inicio:** su stack completo y su complejidad de infraestructura. RB Dispatch debe comenzar con una arquitectura más pequeña que pueda operar y mantener la empresa.

## Referencia complementaria: FleetFlow

https://github.com/adithyavishnubg/FleetFlow

Se presenta como plataforma de logística de entregas para comercio electrónico, con gestión de repartos, conductores, rutas, seguimiento y roles. El README menciona Next.js, React, TypeScript, Fastify, PostgreSQL, Prisma, Redis y Docker.

**Qué conviene estudiar:** separación entre gestión de órdenes, flota, rutas y permisos.

## Referencia de menor ajuste: Courier Management System

https://github.com/Garv19/Courier-Management-System

Proyecto Java descrito de manera general para seguimiento, despacho y administración de mensajería. Su descripción pública no ofrece suficiente detalle arquitectónico para adoptarlo como base principal.

## Conclusión

OwnFleet es la referencia conceptual más cercana por su enfoque de flota propia, mapa, despacho y seguimiento. RB Dispatch debe conservar su propia lógica para Express, Multidrop, Ruta Dedicada, Encomienda, la ZMAX 200, COD, zonas y normativa operativa de Honduras.
