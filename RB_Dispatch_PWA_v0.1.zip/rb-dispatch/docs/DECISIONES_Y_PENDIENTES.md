# RB Dispatch — Decisiones y pendientes de validación

## Decisiones conservadoras de esta iteración

- La ZMoto ZMAX 200 se trata como una unidad con máximo estructural de 500 kg. Se bloquea cualquier solicitud superior.
- Clasificación preliminar: ligera hasta 150 kg y 1.15 m³; pesada si supera 150 kg o 1.15 m³; crítica si supera 350 kg, 1.84 m³ o requiere parrilla/carga larga. La crítica necesita aprobación del operador.
- El volumen declarado se calcula en m³ a partir de dimensiones en centímetros cuando la modalidad solicita medidas.
- Express utiliza los siete rangos de distancia conocidos (10 a 70 km) y los importes por clase registrados en la configuración.
- Dedicada utiliza paquetes de 4 h / 50 km y 8 h / 80 km con máximo de 10 paradas. Si excede el kilometraje incluido, requiere recotización.
- Encomienda aplica como referencia L70 por unidad de hasta 5 kg, hasta 30 km y sin gestión de pisos. Otras condiciones requieren revisión.
- Multidrop admite 2–10 destinos, pero no se inventa un recargo por parada: el precio final se deja a validación manual.

## Confirmaciones requeridas antes de producción

- Validar la tabla completa de tarifas RB Dispatch y si los rangos son acumulativos, por distancia total, zona o tipo de vehículo.
- Confirmar si la categoría pesada se activa por peso **o** por volumen y documentar todos los límites volumétricos y dimensiones máximas de caja/parrilla.
- Definir recargo y reglas de Multidrop: km, número de paradas, tiempo de espera, secuencia y desvíos.
- Confirmar cómo se calculan pisos, peso adicional, embalaje, carga frágil, mercancía de valor, devoluciones y reintentos en Encomienda.
- Definir alcance territorial y regla exacta para servicio fuera de SPS.
- Confirmar manejo de COD, límites de cobro, conciliación, liquidación, comprobantes e incidencias.
- Aprobar Términos y Condiciones, política de privacidad, consentimiento de ubicación, cancelaciones, objetos restringidos, reclamaciones y responsabilidad por la carga.
- Definir perfiles y permisos: cliente, operador, motorista, supervisor y Gerencia General.

## No implementado todavía

Backend, autenticación, base de datos, sincronización entre dispositivos, panel central, asignación, tracking de motorista, notificaciones push, fotos de evidencia, firma/OTP, COD transaccional, reportes, facturación y despliegue de producción.
