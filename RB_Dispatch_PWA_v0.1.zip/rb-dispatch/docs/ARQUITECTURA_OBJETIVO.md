# RB Dispatch — Arquitectura objetivo

**Estado:** propuesta de arquitectura para las siguientes iteraciones. No representa infraestructura ya desplegada.

## Principio de producto

RB Dispatch debe operar como una plataforma logística propia, no como una simple página de solicitud ni como un clon de transporte de pasajeros. El flujo contempla cuatro superficies coordinadas:

1. **Cliente:** cotización, solicitud, datos de remitente/destinatario, mapa, seguimiento y comprobantes visibles.
2. **Despacho:** bandeja central, mapa operativo, validación de carga/tarifa, asignación manual o recomendada, incidencias y liquidaciones.
3. **Motorista:** órdenes asignadas, navegación externa, GPS mientras opera, escaneo/confirmación, evidencias y cierre de servicio.
4. **Seguimiento público:** consulta de estado con enlace/token temporal; sin exponer teléfonos, direcciones completas ni datos internos.

## Arquitectura recomendada por etapas

### Primera etapa de producción

- PWA de cliente y consola web adaptable.
- API central autenticada.
- PostgreSQL administrado con políticas de seguridad por fila (RLS).
- Realtime para cambios de estado y posiciones autorizadas.
- Almacenamiento privado para fotografías y comprobantes.
- Servicio de mapas/rutas con proveedor configurable.
- Registro de auditoría para eventos sensibles y modificaciones administrativas.

Supabase puede cubrir PostgreSQL, Auth, Realtime, Storage y funciones de servidor como primera plataforma, sujeto a revisión de permisos, cuotas, seguridad y costos. No se conectó un proyecto ni se guardaron credenciales en esta iteración.

### Escala posterior

Separar colas, notificaciones, procesamiento de geocodificación, optimización de rutas, analítica y observabilidad cuando el volumen real lo justifique. No introducir Redis, Kubernetes ni microservicios antes de necesitarlo.

## Entidades iniciales sugeridas

- `profiles`: identidad de usuario y rol operativo.
- `customers`: remitentes/negocios y preferencias autorizadas.
- `orders`: modalidad, estado, carga, tarifa estimada, tarifa aprobada, COD y responsable.
- `order_stops`: origen y destinos ordenados, coordenadas y ventanas de servicio.
- `assignments`: vínculo de orden, motorista, vehículo y turno.
- `delivery_events`: bitácora append-only de cambios de estado.
- `proofs`: foto, firma/OTP opcional, coordenadas, fecha y actor que registra la evidencia.
- `vehicles` y `driver_shifts`: capacidad, disponibilidad y operación.
- `pricing_rules`: reglas versionadas con vigencia, zona y modalidad.
- `cash_movements`: COD recibido, liquidación, diferencias y autorización.
- `incidents` y `claims`: incidencias, reclamos, resolución y evidencia.

## Estados propuestos para validar

`draft → submitted → needs_review / quoted → accepted → assigned → picked_up → in_transit → delivered`.

Estados alternos sugeridos: `cancelled`, `delivery_attempt_failed`, `return_pending`, `returned`, `claim_open`. Cada transición debe validar rol, precondiciones, evidencia y marca de tiempo. No se debe permitir editar una entrega cerrada sin un evento correctivo auditable.

## Límites de seguridad

- Roles mínimos: cliente, operador, motorista, supervisor y Gerencia General.
- RLS en todas las tablas con datos de cliente u operación.
- Datos sensibles de remitentes/destinatarios solo visibles para quienes los necesitan para ejecutar el servicio.
- Enlaces públicos de seguimiento con token aleatorio, vencimiento y revocación.
- Ubicación del motorista solo durante turno/servicio activo y según política aprobada.
- Fotos y evidencias en buckets privados con URLs firmadas y vencimiento.
- No poner claves de servicio, service-role keys o secretos en JavaScript del navegador ni en Git.
- Validar de nuevo en backend peso, capacidad, tarifas, zonas, pagos y permisos; nunca confiar en el cálculo del navegador.

## Decisión de despliegue

El repositorio actual es público. Solo debe contener código, documentación y configuración no sensible. Datos de clientes, credenciales, claves privadas, tokens de producción y archivos de guías no deben subirse al repositorio.
