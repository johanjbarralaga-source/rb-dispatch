'use strict';

const CONFIG = {
  company: 'Rutas Barralaga',
  localStorageKey: 'rb-dispatch-drafts-v1',
  vehicle: { name: 'ZMoto ZMAX 200', boxVolumeM3: 2.288, nominalKg: 350, structuralKg: 500 },
  express: {
    light:    { label: 'Ligera', rate: 3.50, speeds: '24 km/h', serviceMin: 20, fares: [150,250,350,450,560,660,760], extraKm: 12 },
    heavy:    { label: 'Pesada', rate: 4.80, speeds: '20 km/h', serviceMin: 35, fares: [210,340,480,620,750,890,1030], extraKm: 15 },
    critical: { label: 'Crítica', rate: 6.50, speeds: '16 km/h', serviceMin: 50, fares: [320,520,730,930,1130,1330,1530], extraKm: 20 }
  },
  dedicated: { fourHours: [750,870,1130], eightHours: [1380,1580,2050] },
  encomienda: { upTo5Kg: 70, maxKm: 30 }
};

const state = {
  service: 'express', map: null, markers: new Map(), routeLayer: null,
  pins: { pickup: null, drops: [null] }, quote: null, lastRouteKm: null,
  currentMapTarget: 'pickup'
};

const $ = (id) => document.getElementById(id);
const escapeHtml = (v) => String(v ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const money = (v) => new Intl.NumberFormat('es-HN',{style:'currency',currency:'HNL',maximumFractionDigits:0}).format(v);
const number = (v) => Number.parseFloat(v || '0') || 0;

function serviceMarkup(service) {
  if (service === 'express') return `
    <h3 class="subheading">Características de la carga</h3>
    <div class="fields-grid">
      <label>Peso total (kg)<input name="packageWeight" type="number" min="0.1" max="500" step="0.1" placeholder="Ej. 35" required><span class="field-help">Máximo estructural: 500 kg.</span></label>
      <label>Largo × ancho × alto (cm)<div class="field-row"><input name="lengthCm" type="number" min="1" placeholder="Largo" required><input name="widthCm" type="number" min="1" placeholder="Ancho" required></div><input name="heightCm" type="number" min="1" placeholder="Alto (cm)" required></label>
      <label>Tipo de carga<select name="cargoType"><option value="general">General</option><option value="fragile">Frágil</option><option value="long">Larga / sobredimensionada</option><option value="parrilla">Requiere parrilla</option></select></label>
    </div>
    <div class="field-help">La categoría de vehículo se estima por peso y volumen. Cargas críticas requieren aprobación del operador.</div>`;
  if (service === 'multidrop') return `
    <h3 class="subheading">Carga y paradas</h3>
    <div class="fields-grid">
      <label>Peso total de la carga (kg)<input name="packageWeight" type="number" min="0.1" max="500" step="0.1" placeholder="Peso total de la ruta" required></label>
      <label>Volumen aproximado (m³)<input name="manualVolume" type="number" min="0" max="2.288" step="0.01" placeholder="Ej. 0.85"></label>
      <label>Número de entregas<select name="stopCount" id="stop-count">${Array.from({length:9},(_,i)=>`<option value="${i+2}" ${i===0?'selected':''}>${i+2} destinos</option>`).join('')}</select></label>
    </div>
    <div class="field-help">Una recolección y de 2 a 10 destinos, respetando el orden de la ruta. La tarifa multidestino debe confirmarse en la central.</div>
    <div id="extra-destinations"></div>`;
  if (service === 'dedicada') return `
    <h3 class="subheading">Configuración de ruta dedicada</h3>
    <div class="fields-grid">
      <label>Bloque de servicio<select name="dedicatedBlock"><option value="4">4 horas · hasta 50 km</option><option value="8">8 horas · hasta 80 km</option></select></label>
      <label>Peso total (kg)<input name="packageWeight" type="number" min="0.1" max="500" step="0.1" placeholder="Peso total" required></label>
      <label>Número de paradas<input name="stopCount" id="stop-count" type="number" min="1" max="10" value="1" required></label>
    </div>
    <div class="field-help">Máximo 10 paradas. La primera corresponde al destinatario indicado arriba. El remitente debe realizar prepago.</div>
    <div id="extra-destinations"></div>`;
  return `
    <h3 class="subheading">Datos de encomienda</h3>
    <div class="fields-grid">
      <label>Peso por unidad (kg)<input name="unitWeight" type="number" min="0.1" step="0.1" max="500" value="1" required></label>
      <label>Cantidad de unidades<input name="unitCount" type="number" min="1" max="100" value="1" required></label>
      <label>Piso de entrega<select name="floor"><option value="0">Planta baja</option><option value="1">1.er piso</option><option value="2">2.º piso</option><option value="3">3.er piso o más</option></select></label>
    </div>
    <div class="field-help">Referencia de tarifa registrada: L70 por unidad de hasta 5 kg. Límites de ruta, peso, pisos y manejo especial requieren validación.</div>`;
}

function renderServiceFields() {
  $('service-fields').innerHTML = serviceMarkup(state.service);
  document.querySelectorAll('.service-card').forEach(btn => {
    const active = btn.dataset.service === state.service;
    btn.classList.toggle('active', active);
    btn.setAttribute('aria-pressed', String(active));
  });
  if (state.service === 'multidrop' || state.service === 'dedicada') {
    $('stop-count').addEventListener('change', renderExtraDestinations);
    renderExtraDestinations();
  }
  updateMapTargetOptions();
  state.quote = null;
  $('save-draft').disabled = true;
  $('quote-price').textContent = '—';
  $('quote-summary').innerHTML = '<div class="empty-state"><span>＋</span><strong>Completa tu solicitud</strong><small>Genera una nueva propuesta para esta modalidad.</small></div>';
}

function renderExtraDestinations() {
  const count = Number($('stop-count')?.value || (state.service === 'multidrop' ? 2 : 1));
  const host = $('extra-destinations');
  if (!host) return;
  // The main recipient card represents destination/stop 1. Only render stops 2..N here.
  host.innerHTML = Array.from({length:Math.max(0,count-1)},(_,j)=>{
    const i=j+1;
    return `
      <div class="destination-item">
        <div class="destination-head"><span>${state.service==='multidrop'?'Destino':'Parada'} ${i+1}</span><span>Orden ${i+1}</span></div>
        <div class="destination-grid">
          <label>Nombre de quien recibe<input name="stopName${i}" placeholder="Persona o negocio" required></label>
          <label>Teléfono<input name="stopPhone${i}" inputmode="tel" placeholder="9999-9999"></label>
          <label>Colonia / sector<input name="stopArea${i}" placeholder="Colonia" required></label>
          <label>Dirección y referencias<input name="stopAddress${i}" placeholder="Dirección completa" required></label>
        </div>
      </div>`;
  }).join('');
  state.pins.drops = Array.from({length:count},(_,i)=>state.pins.drops[i] || null);
  updateMapTargetOptions();
}

function updateMapTargetOptions() {
  const select = $('map-target');
  if (!select) return;
  const count = ['multidrop','dedicada'].includes(state.service) ? Number($('stop-count')?.value || (state.service === 'multidrop' ? 2 : 1)) : 1;
  const current = select.value;
  select.innerHTML = `<option value="pickup">Recolección</option>${Array.from({length:count},(_,i)=>`<option value="drop-${i}">${state.service==='multidrop'?'Destino '+(i+1):'Entrega'}</option>`).join('')}`;
  select.value = [...select.options].some(o=>o.value===current) ? current : 'pickup';
  state.currentMapTarget = select.value;
  renderMarkers();
}

function initMap() {
  if (!window.L) {
    $('map-status').textContent = 'Mapa no disponible sin conexión';
    $('map').innerHTML = '<div class="warning">No se pudo cargar el mapa. Revisa tu conexión a internet y recarga la página.</div>';
    return;
  }
  state.map = L.map('map',{scrollWheelZoom:false}).setView([15.5042,-88.0250],12);
  L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',{
    maxZoom:19, attribution:'&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
  }).addTo(state.map);
  state.map.on('click', e => setPin(state.currentMapTarget,e.latlng.lat,e.latlng.lng));
  $('map-status').textContent = 'Mapa listo · toca para colocar pines';
  setTimeout(()=>state.map.invalidateSize(),250);
}

function pinIcon(kind,label) {
  const color = kind === 'pickup' ? '#14b8a6' : '#c9a84c';
  return L.divIcon({className:'',html:`<div style="width:28px;height:28px;border:3px solid #fff;border-radius:50% 50% 50% 3px;transform:rotate(-45deg);background:${color};box-shadow:0 2px 9px #0005;display:grid;place-items:center"><span style="transform:rotate(45deg);font-size:10px;font-weight:900;color:#172641">${escapeHtml(label)}</span></div>`,iconSize:[28,28],iconAnchor:[14,27]});
}

function pinValue(key) {
  if (key === 'pickup') return state.pins.pickup;
  const i = Number(key.split('-')[1]);
  return state.pins.drops[i] || null;
}
function setPin(key,lat,lng) {
  const point = {lat:Number(lat),lng:Number(lng)};
  if (key === 'pickup') state.pins.pickup = point;
  else state.pins.drops[Number(key.split('-')[1])] = point;
  renderMarkers();
  $('route-distance').textContent = 'Pines actualizados';
  $('route-note').textContent = 'Calcula la propuesta para consultar la ruta por carretera.';
}
function allRoutePoints() {
  const points = [];
  if (state.pins.pickup) points.push(state.pins.pickup);
  const count = ['multidrop','dedicada'].includes(state.service) ? Number($('stop-count')?.value || (state.service === 'multidrop' ? 2 : 1)) : 1;
  points.push(...state.pins.drops.slice(0,count).filter(Boolean));
  return points;
}
function renderMarkers() {
  if (!state.map) return;
  for (const marker of state.markers.values()) state.map.removeLayer(marker);
  state.markers.clear();
  if (state.pins.pickup) state.markers.set('pickup',L.marker([state.pins.pickup.lat,state.pins.pickup.lng],{icon:pinIcon('pickup','R')}).addTo(state.map).bindPopup('Punto de recolección'));
  const count = ['multidrop','dedicada'].includes(state.service) ? Number($('stop-count')?.value || (state.service === 'multidrop' ? 2 : 1)) : 1;
  state.pins.drops.slice(0,count).forEach((p,i)=>{if(p)state.markers.set('drop-'+i,L.marker([p.lat,p.lng],{icon:pinIcon('drop',String(i+1))}).addTo(state.map).bindPopup((state.service==='dedicada'?'Parada ':'Destino ')+(i+1)));});
  const pts = allRoutePoints();
  if (pts.length) state.map.fitBounds(pts.map(p=>[p.lat,p.lng]),{padding:[30,30],maxZoom:14});
}

async function geocodeAddress(query) {
  const url = new URL('https://nominatim.openstreetmap.org/search');
  url.search = new URLSearchParams({q:query+', Honduras',format:'jsonv2',countrycodes:'hn',limit:'1'}).toString();
  const response = await fetch(url.toString(),{headers:{'Accept':'application/json'}});
  if (!response.ok) throw new Error('No se pudo consultar el buscador geográfico.');
  const data = await response.json();
  if (!data.length) throw new Error('No se encontró la dirección. Prueba con colonia, municipio y referencia.');
  return {lat:Number(data[0].lat),lng:Number(data[0].lon),label:data[0].display_name};
}

async function findPlace() {
  const q = $('place-query').value.trim();
  if (!q) return showMessage('Escribe una dirección o colonia para buscar.');
  $('find-place').disabled = true;
  $('find-place').textContent = 'Buscando…';
  try {
    const result = await geocodeAddress(q);
    setPin(state.currentMapTarget,result.lat,result.lng);
    if (state.map) state.map.setView([result.lat,result.lng],16);
    $('route-note').textContent = 'Ubicación encontrada: '+result.label;
    showMessage('Pin colocado en el mapa.');
  } catch(err) { showMessage(err.message); }
  finally {$('find-place').disabled=false;$('find-place').textContent='Buscar';}
}

async function getRouteDistance() {
  const points = allRoutePoints();
  const expectedDrops = ['multidrop','dedicada'].includes(state.service) ? Number($('stop-count')?.value || (state.service === 'multidrop' ? 2 : 1)) : 1;
  if (!state.pins.pickup || state.pins.drops.slice(0,expectedDrops).some(p=>!p)) {
    throw new Error('Coloca el pin de recolección y todos los destinos antes de calcular la tarifa.');
  }
  const coordString = points.map(p=>`${p.lng},${p.lat}`).join(';');
  const url = `https://router.project-osrm.org/route/v1/driving/${coordString}?overview=full&geometries=geojson&steps=false`;
  const response = await fetch(url);
  if (!response.ok) throw new Error('No fue posible calcular la ruta. Intenta nuevamente.');
  const data = await response.json();
  if (data.code !== 'Ok' || !data.routes?.length) throw new Error('No se encontró una ruta por carretera entre los puntos.');
  const route = data.routes[0];
  const km = route.distance / 1000;
  state.lastRouteKm = km;
  if (state.routeLayer) state.map.removeLayer(state.routeLayer);
  state.routeLayer = L.geoJSON(route.geometry,{style:{color:'#14b8a6',weight:5,opacity:.85}}).addTo(state.map);
  $('route-distance').textContent = `${km.toFixed(1)} km`;
  $('route-note').textContent = `Recorrido estimado por carretera · ${Math.round(route.duration/60)} min de conducción referencial.`;
  return km;
}

function getFormData() {
  const fd = new FormData($('order-form'));
  const obj = Object.fromEntries(fd.entries());
  obj.service = state.service;
  obj.pins = JSON.parse(JSON.stringify(state.pins));
  obj.savedAt = new Date().toISOString();
  return obj;
}
function classifyLoad(weight,volume,cargoType='general') {
  if (weight > CONFIG.vehicle.structuralKg) return {error:`La carga supera el máximo estructural de ${CONFIG.vehicle.structuralKg} kg. No se puede cotizar en esta unidad.`};
  if (weight <= 0) return {error:'Ingresa el peso total de la carga.'};
  if (cargoType === 'long' || cargoType === 'parrilla' || volume > 1.84 || weight > 350) return {key:'critical',...CONFIG.express.critical,approval:true};
  if (weight > 150 || volume > 1.15) return {key:'heavy',...CONFIG.express.heavy,approval:false};
  return {key:'light',...CONFIG.express.light,approval:false};
}
function estimateExpress(km,load,outsideSps) {
  if (km > 150) return {manual:true,reason:'Recorridos superiores a 150 km requieren cotización manual.'};
  const thresholds = [10,20,30,40,50,60,70];
  let idx = thresholds.findIndex(t=>km<=t);
  if (idx < 0) idx = 6;
  const billingKm = outsideSps ? Math.max(km,30) : km;
  let amount;
  if (billingKm <= 70) {
    let bi = thresholds.findIndex(t=>billingKm<=t); if(bi<0)bi=6;
    amount = load.fares[bi];
  } else {
    amount = load.fares[6] + Math.ceil(billingKm-70)*load.extraKm;
  }
  return {amount,band:idx,extra:billingKm>70?Math.ceil(billingKm-70):0,outsideSps};
}
function quoteData(data,km) {
  const weight = state.service==='encomienda' ? number(data.unitWeight)*number(data.unitCount) : number(data.packageWeight);
  const volume = data.manualVolume !== undefined ? number(data.manualVolume) : (number(data.lengthCm)*number(data.widthCm)*number(data.heightCm))/1000000;
  if (weight > CONFIG.vehicle.structuralKg) return {blocked:true,reason:`La carga total es de ${weight.toFixed(1)} kg y supera el máximo estructural de 500 kg. Divide la carga o solicita una evaluación de otra unidad.`};
  if (weight <= 0) return {blocked:true,reason:'El peso debe ser mayor que cero.'};
  if (state.service === 'multidrop') return {manual:true,amount:null,load:classifyLoad(weight,volume),reason:'La ruta Multidrop requiere validar secuencia, tiempos de parada y tarifa consolidada antes de emitir un precio final.'};
  if (state.service === 'dedicada') {
    const stops = number(data.stopCount);
    if (stops<1 || stops>10) return {blocked:true,reason:'Ruta dedicada: se permiten de 1 a 10 paradas.'};
    const load = classifyLoad(weight,0);
    const table = data.dedicatedBlock==='8' ? CONFIG.dedicated.eightHours : CONFIG.dedicated.fourHours;
    const index = load.key==='light'?0:load.key==='heavy'?1:2;
    const maxKm = data.dedicatedBlock==='8'?80:50;
    return {amount:table[index],manual:km>maxKm || load.approval,reason:km>maxKm?`La ruta supera los ${maxKm} km incluidos; requiere recotización.`:load.approval?'La carga crítica requiere aprobación del operador.':'Tarifa base de bloque, sujeta a disponibilidad y validación de paradas.',load,block:data.dedicatedBlock,maxKm,stops};
  }
  if (state.service === 'encomienda') {
    const unitWeight=number(data.unitWeight),units=number(data.unitCount),floor=number(data.floor);
    if (unitWeight>5) return {manual:true,reason:'La referencia L70 por unidad aplica únicamente a paquetes de hasta 5 kg.'};
    if (km>CONFIG.encomienda.maxKm) return {manual:true,reason:'La encomienda excede el radio de referencia de 30 km en SPS.'};
    if (floor>0) return {manual:true,reason:'La entrega en pisos requiere revisar acceso, manipulación y recargos aplicables.'};
    return {amount:units*CONFIG.encomienda.upTo5Kg,manual:false,reason:'Referencia base L70 por unidad de hasta 5 kg. Confirmar dimensiones, manejo y disponibilidad.',units};
  }
  const load = classifyLoad(weight,volume,data.cargoType);
  if (load.error) return {blocked:true,reason:load.error};
  if (volume > CONFIG.vehicle.boxVolumeM3) return {manual:true,reason:'El volumen excede la caja seca registrada de 2.288 m³. Requiere validar configuración de parrilla, dimensiones y seguridad.' ,load};
  const fare=estimateExpress(km,load,Boolean(data.outsideSps));
  if (fare.manual) return {manual:true,reason:fare.reason,load};
  return {amount:fare.amount,manual:load.approval,reason:load.approval?'Clasificación crítica: precio referencial sujeto a autorización del operador.':'Estimación de tarifa Express por rango de distancia y clasificación de carga.',load,fare,volume};
}

function renderQuote(data,km,result) {
  const serviceNames={express:'Express',multidrop:'Multidrop',dedicada:'Ruta dedicada',encomienda:'Encomienda'};
  const destinationCount = ['multidrop','dedicada'].includes(state.service) ? number(data.stopCount) : 1;
  const sender = escapeHtml(data.senderName||'—');
  const recipient = state.service==='multidrop' ? `${destinationCount} destinos` : state.service==='dedicada' ? `${destinationCount} paradas` : escapeHtml(data.recipientName||'—');
  const lines=[['Modalidad',serviceNames[state.service]],['Remitente',sender],['Destino',recipient],['Distancia',`${km.toFixed(1)} km`],['Carga',`${(state.service==='encomienda'?number(data.unitWeight)*number(data.unitCount):number(data.packageWeight)).toFixed(1)} kg`]];
  if(result.load) lines.push(['Clasificación',result.load.label]);
  $('quote-summary').innerHTML=lines.map(([k,v])=>`<div class="summary-line"><span>${escapeHtml(k)}</span><b>${escapeHtml(v)}</b></div>`).join('');
  $('quote-price').textContent=result.amount!=null?money(result.amount):'Cotización manual';
  $('price-caption').textContent=result.blocked?'Servicio no cotizable':result.manual?'Precio sujeto a validación':'Estimación preliminar';
  $('price-note').textContent=result.reason || 'La tarifa final se confirma al validar operación y disponibilidad.';
  if(result.blocked){$('quote-price').textContent='No disponible';$('price-caption').textContent='Límite operativo';$('save-draft').disabled=true;}
  else $('save-draft').disabled=false;
  state.quote={data,km,result};
}

function showMessage(message) {
  $('save-message').textContent=message;
  if(message) setTimeout(()=>{if($('save-message').textContent===message)$('save-message').textContent='';},6000);
}

async function calculate() {
  const form=$('order-form');
  const fields=[...form.querySelectorAll('input[required],textarea[required],select[required]')];
  const invalid=fields.find(el=>!el.value.trim());
  if(invalid){invalid.classList.add('field-error');invalid.focus();showMessage('Completa los campos obligatorios antes de calcular.');return;}
  if(!form.elements.acceptTerms.checked){showMessage('Debes confirmar los datos y la validación de tarifa.');return;}
  const data=getFormData();
  const totalWeight=state.service==='encomienda'?number(data.unitWeight)*number(data.unitCount):number(data.packageWeight);
  if(totalWeight>500){$('quote-price').textContent='No disponible';$('price-caption').textContent='Límite de carga superado';$('price-note').textContent='El máximo estructural registrado para la unidad es 500 kg.';showMessage('La carga supera 500 kg. Solicitud bloqueada.');return;}
  $('calculate').disabled=true;$('calculate').textContent='Calculando ruta…';
  try {
    const km=await getRouteDistance();
    const result=quoteData(data,km);
    renderQuote(data,km,result);
    showMessage(result.blocked?'La operación excede los límites configurados.':'Propuesta generada. Requiere confirmación operativa.');
  } catch(err) {showMessage(err.message);}
  finally {$('calculate').disabled=false;$('calculate').textContent='Calcular propuesta';}
}

function loadDrafts(){try{return JSON.parse(localStorage.getItem(CONFIG.localStorageKey)||'[]');}catch{return [];}}
function saveDraft(){
  if(!state.quote || state.quote.result.blocked) return;
  const list=loadDrafts();
  const d=state.quote.data;
  const id='RB-'+Date.now().toString(36).toUpperCase();
  list.unshift({id,savedAt:new Date().toISOString(),service:state.service,sender:d.senderName||'',recipient:d.recipientName||'',km:state.quote.km,amount:state.quote.result.amount,manual:state.quote.result.manual,localOnly:true});
  try{localStorage.setItem(CONFIG.localStorageKey,JSON.stringify(list.slice(0,30)));renderDrafts();showMessage('Borrador guardado solamente en este dispositivo. No fue enviado a la central.');}
  catch{showMessage('No se pudo guardar. El almacenamiento del navegador puede estar lleno o deshabilitado.');}
}
function renderDrafts(){
  const list=loadDrafts();$('draft-count').textContent=String(list.length);
  $('draft-list').innerHTML=list.length?list.slice(0,5).map(d=>`<div class="draft-entry"><strong>${escapeHtml(d.id)} · ${escapeHtml(d.service)}</strong><span>${escapeHtml(d.sender)} → ${escapeHtml(d.recipient||'Destinos')} · ${Number(d.km).toFixed(1)} km</span></div>`).join(''):'<p class="muted">Todavía no hay borradores guardados en este equipo.</p>';
}

function locateMe(){
  if(!navigator.geolocation){showMessage('Este navegador no ofrece geolocalización.');return;}
  $('locate-me').disabled=true;
  navigator.geolocation.getCurrentPosition(pos=>{
    const {latitude,longitude}=pos.coords;
    if(state.map)state.map.setView([latitude,longitude],16);
    setPin(state.currentMapTarget,latitude,longitude);
    $('locate-me').disabled=false;
  },err=>{showMessage(err.code===1?'Permite el acceso a ubicación para usar esta función.':'No se pudo obtener tu ubicación.');$('locate-me').disabled=false;},{enableHighAccuracy:true,timeout:12000,maximumAge:30000});
}

function bindEvents(){
  document.querySelectorAll('.service-card').forEach(btn=>btn.addEventListener('click',()=>{state.service=btn.dataset.service;state.pins.drops=[null];if(state.routeLayer&&state.map){state.map.removeLayer(state.routeLayer);state.routeLayer=null;}renderServiceFields();}));
  $('map-target').addEventListener('change',e=>{state.currentMapTarget=e.target.value;});
  $('find-place').addEventListener('click',findPlace);
  $('place-query').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();findPlace();}});
  $('locate-me').addEventListener('click',locateMe);
  $('calculate').addEventListener('click',calculate);
  $('save-draft').addEventListener('click',saveDraft);
  $('order-form').addEventListener('input',e=>{e.target.classList.remove('field-error');if(state.quote){state.quote=null;$('save-draft').disabled=true;}});
}

function registerServiceWorker(){
  if('serviceWorker' in navigator && location.protocol.startsWith('http')) navigator.serviceWorker.register('./sw.js').catch(()=>{});
}

function init(){
  $('year').textContent=String(new Date().getFullYear());
  renderServiceFields();
  bindEvents();
  initMap();
  renderDrafts();
  registerServiceWorker();
}

document.addEventListener('DOMContentLoaded',init);
